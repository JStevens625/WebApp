<!--Jacob Stevens COP 3834C.01 Web Application Development 12/5/17  PHP 3-->
<html>
<style>
body{
  background-color: rgb(115, 11, 142);
}
</style>
<head>
  <meta charset="UTF-8">
</head>
<body>
  <form action="./BackEnd.php" method="post">
    First Term: <input type="text" name="first">
    <br />
    <br />
    Common Ratio: <input type="text" name="ratio">
    <br />
    <br />
    <input type="submit" value="Submit">
  </form>
</body>
</html>
